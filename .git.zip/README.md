# Quick-Chat
MERN-Based Real-Time Chat Experience


  16-09-2025
      - Started working on Backend


      
   17-09-2025
      - creted server and connection with MongoDB



      
  18-09-2025
      - Started to work on api writing


  19-09-2025
      - Api's for login and registration


  24-09-2025
    - Completed writing Controller for User and stated to work on routes(API End Points) and also learning about cloudinary


 26-09-2025
 -Started To work on messages (Creating Modals , Api's........)

 29-09-2025
 - Writing API's for meassage modal in controller
      
1. react-hot-toast

👉 For toast notifications (alerts/messages)

Use it for:
Showing success or error messages
Showing loading states (toast.promise)
Giving users quick feedback

2. axios

👉 For HTTP requests (fetching/sending data to APIs)

Use it for:
Making API calls (GET, POST, PUT, DELETE)
Handling authentication tokens
Interacting with backend endpoints

3. socket.io-client

👉 For real-time communication between frontend and backend

Use it for:
Chat applications 💬
Live notifications 🔔
Real-time dashboards 📊